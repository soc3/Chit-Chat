package groupon.user;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
;
/**
 *
 * @author sushant oberoi
 */
public class Utilities {
    public static final int PORT = 6289;
    public static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    public static final String JDBC_PATH = "jdbc:mysql://localhost/groupon";
    public static final String IP = "localhost";
}
